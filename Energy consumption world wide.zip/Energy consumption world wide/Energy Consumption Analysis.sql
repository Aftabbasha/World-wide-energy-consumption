CREATE DATABASE ENERGY;
USE ENERGY;

-- 1. country_3
CREATE TABLE country_3 (
  CID VARCHAR(10) PRIMARY KEY,
  Country VARCHAR(100),
  UNIQUE INDEX idx_country_name (Country)
);
SELECT * FROM country_3;


-- 2. emission_3
CREATE TABLE emission_3 (
  Country VARCHAR(100),
  energy_type VARCHAR(50),
  year INT,
  emission INT,
  per_capita_emission DOUBLE,
  FOREIGN KEY (Country) REFERENCES country_3(Country)
);

SELECT * FROM emission_3;


-- 3. population
CREATE TABLE population (
  countries VARCHAR(100),
  year INT,
  Value DOUBLE,
  FOREIGN KEY (countries) REFERENCES country_3(Country)
);

SELECT * FROM population;


-- 4. production
CREATE TABLE production (
  country VARCHAR(100),
  energy VARCHAR(50),
  year INT,
  production INT,
  FOREIGN KEY (country) REFERENCES country_3(Country)
);

SELECT * FROM production;


-- 5. gdp_3
CREATE TABLE gdp_3 (
  Country VARCHAR(100),
  year INT,
  Value DOUBLE,
  FOREIGN KEY (Country) REFERENCES country_3(Country)
);
SELECT * FROM gdp_3;


-- 6. consumption
CREATE TABLE consumption (
  country VARCHAR(100),
  energy VARCHAR(50),
  year INT,
  consumption INT,
  FOREIGN KEY (country) REFERENCES country_3(Country)
);

SELECT * FROM consumption;


-- General & Comparative Analysis

-- What is the total emission per country for the most recent year available?
SELECT country, SUM(emission) AS total_emissions
FROM emission_3
WHERE year = (SELECT MAX(year) FROM emission_3)
GROUP BY country
ORDER BY total_emissions DESC;

-- What are the top 5 countries by GDP in the most recent year?
SELECT Country AS country, Value AS GDP
FROM gdp_3
WHERE year = (SELECT MAX(year) FROM gdp_3)
ORDER BY GDP DESC
LIMIT 5;

-- Compare energy production and consumption by country and year.
SELECT p.country, p.year,
       p.total_production, c.total_consumption
FROM (
  SELECT country, year, SUM(production) AS total_production
  FROM production
  GROUP BY country, year
) AS p
JOIN (
  SELECT country, year, SUM(consumption) AS total_consumption
  FROM consumption
  GROUP BY country, year
) AS c
  ON p.country = c.country AND p.year = c.year
ORDER BY p.country, p.year DESC;

-- Which energy types contribute most to emissions across all countries?
SELECT energy_type, SUM(emission) AS total_emissions
FROM emission_3
GROUP BY energy_type
ORDER BY total_emissions DESC;


-- Trend Analysis Over Time

-- How have global emissions changed year over year?
SELECT e1.year AS Year,
       SUM(e1.emission) AS total_emissions,
       (SUM(e1.emission) - SUM(e2.emission)) AS change_from_previous
FROM emission_3 e1
JOIN emission_3 e2 ON e1.year = e2.year + 1
GROUP BY e1.year
ORDER BY e1.year;

-- What is the trend in GDP for each country over the given years?
SELECT Country AS country, year, Value AS GDP
FROM gdp_3
ORDER BY country, year;

-- How has population growth affected total emissions in each country?
SELECT pop.countries AS country, pop.year,
       pop.Value AS population,
       e.total_emissions
FROM population pop
JOIN (
  SELECT country, year, SUM(emission) AS total_emissions
  FROM emission_3
  GROUP BY country, year
) e
  ON pop.countries = e.country AND pop.year = e.year
ORDER BY country, year;

-- Has energy consumption increased or decreased over the years for major economies?
SELECT country, year, SUM(consumption) AS total_consumption
FROM consumption
WHERE country IN ('United States', 'China', 'India')
GROUP BY country, year
ORDER BY country, year;

-- What is the average yearly change in emissions per capita for each country?
SELECT e1.country, e1.year,
       e1.per_capita_emission - e2.per_capita_emission AS annual_change
FROM emission_3 e1
JOIN emission_3 e2 ON e1.country = e2.country AND e1.year = e2.year + 1;

SELECT country, AVG(annual_change) AS avg_yearly_percapita_change
FROM (
  SELECT e1.country, e1.per_capita_emission - e2.per_capita_emission AS annual_change
  FROM emission_3 e1
  JOIN emission_3 e2 
    ON e1.country = e2.country AND e1.year = e2.year + 1
) sub
GROUP BY country;


-- Ratio & Per Capita Analysis 

-- What is the emission-to-GDP ratio for each country by year?
SELECT e.country, e.year,
       SUM(e.emission) / AVG(g.Value) AS emission_to_GDP_ratio
FROM emission_3 e
JOIN gdp_3 g ON e.country = g.Country AND e.year = g.year
GROUP BY e.country, e.year
ORDER BY emission_to_GDP_ratio DESC;

-- What is the energy consumption per capita for each country over the last decade?
SELECT c.country, c.year,
       SUM(c.consumption) / AVG(p.Value) AS consumption_per_capita
FROM consumption c
JOIN population p ON c.country = p.countries AND c.year = p.year
WHERE c.year >= (SELECT MAX(year) - 10 FROM consumption)
GROUP BY c.country, c.year;

-- How does energy production per capita vary across countries?
SELECT pr.country, pr.year,
       SUM(pr.production) / AVG(p.Value) AS production_per_capita
FROM production pr
JOIN population p ON pr.country = p.countries AND pr.year = p.year
GROUP BY pr.country, pr.year;

-- Which countries have the highest energy consumption relative to GDP?
SELECT c.country, c.year,
       SUM(c.consumption) / AVG(g.Value) AS consumption_to_GDP_ratio
FROM consumption c
JOIN gdp_3 g ON c.country = g.Country AND c.year = g.year
GROUP BY c.country, c.year
ORDER BY consumption_to_GDP_ratio DESC;

-- What is the correlation between GDP growth and energy production growth?
SELECT g.Country, g.year,
       (g.Value - LAG(g.Value) OVER (PARTITION BY g.Country ORDER BY g.year)) / LAG(g.Value) OVER (PARTITION BY g.Country ORDER BY g.year) AS GDP_growth_rate,
       (p_sum.total_production - LAG(p_sum.total_production) OVER (PARTITION BY p_sum.country ORDER BY p_sum.year)) / LAG(p_sum.total_production) OVER (PARTITION BY p_sum.country ORDER BY p_sum.year) AS production_growth_rate
FROM gdp_3 g
JOIN (
    SELECT country, year, SUM(production) AS total_production
    FROM production
    GROUP BY country, year
) p_sum ON g.Country = p_sum.country AND g.year = p_sum.year;



-- Global Comparisons

-- What are the top 10 countries by population and how do their emissions compare?
SELECT pop.countries AS country, pop.Value AS population, e.total_emissions
FROM (
  SELECT countries, Value
  FROM population
  WHERE year = (SELECT MAX(year) FROM population)
  ORDER BY Value DESC
  LIMIT 10
) pop
LEFT JOIN (
  SELECT country, SUM(emission) AS total_emissions
  FROM emission_3
  WHERE year = (SELECT MAX(year) FROM emission_3)
  GROUP BY country
) e ON pop.countries = e.country
ORDER BY pop.Value DESC;

-- Which countries have improved (reduced) their per capita emissions the most over the last decade?
SELECT e_end.country,
       (e_start.per_capita_emission - e_end.per_capita_emission) AS percapita_drop
FROM emission_3 e_start
JOIN emission_3 e_end 
  ON e_start.country = e_end.country
WHERE e_start.year = (SELECT MIN(year) FROM emission_3)
  AND e_end.year = (SELECT MAX(year) FROM emission_3)
ORDER BY percapita_drop DESC
LIMIT 5;

-- What is the global share (%) of emissions by country?
SELECT country,
       SUM(emission) * 100.0 / (SELECT SUM(emission) FROM emission_3 WHERE year = (SELECT MAX(year) FROM emission_3)) AS pct_of_global
FROM emission_3
WHERE year = (SELECT MAX(year) FROM emission_3)
GROUP BY country
ORDER BY pct_of_global DESC;

-- What is the global average GDP, emission, and population by year?
SELECT g.year,
       AVG(g.Value) AS avg_GDP,
       (SELECT AVG(Value) FROM population WHERE year = g.year) AS avg_population,
       (SELECT AVG(e.total_em) 
        FROM (SELECT year, SUM(emission) AS total_em FROM emission_3 GROUP BY year) e
        WHERE e.year = g.year) AS avg_emissions
FROM gdp_3 g
GROUP BY g.year;